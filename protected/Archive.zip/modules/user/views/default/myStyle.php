<style>
    .content {
        padding-top: 0 !important;


    }
    .small-box:hover{
        color: red;
        background: #935c25
    }
    .small-box{
        margin-bottom: 0px;
        margin-top: 4px;
        border: none !important;
        cursor:pointer;
    }

    .nav-tabs-custom>.tab-content {
        /* background: #fff; */
        padding: 0;
        /* border-bottom-right-radius: 3px; */
        /* border-bottom-left-radius: 3px; */
    }

    .img-thumbnail {
        height: 100px !important;
        width: 120px !important;
    }


    .clicked {
        background-color: blue;
    }

    [class^='select2'] {
        border-radius: 0px !important;
        min-height: 30px !important;
    }

    .select2-selection__arrow{
        display: none;
    }

    .btn-app{
        background-color: #00c0ef !important;
        color: white;
    }


    .myProducts {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }
    


</style>