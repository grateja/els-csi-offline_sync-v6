<div class="col-md-5">
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Create - Salary Expenses</h3>
        </div>
        <?php echo $this->renderPartial('_formSalaries', array('model' => $model)); ?>
    </div>
</div>