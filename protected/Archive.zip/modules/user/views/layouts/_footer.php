<footer class="main-footer">
    <strong>Copyright &copy; 2018 <a href="http://AppWard.com">AppWard Group</a>.</strong> All rights reserved.
</footer>
