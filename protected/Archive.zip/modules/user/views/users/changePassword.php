

<div class="col-md-6">
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Change Password</h3>
        </div>
        <?php echo $this->renderPartial('_changePassword', array('model' => $model)); ?>
    </div>
</div>