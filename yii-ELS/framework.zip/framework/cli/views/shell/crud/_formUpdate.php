<?php
/**
 * This is the template for generating the form view for crud.
 * The following variables are available in this template:
 * - $ID: the primary key name
 * - $modelClass: the model class name
 * - $columns: a list of column schema objects
 */
?>
<!-- widget div-->
<div>
	<!-- widget edit box -->
	<div class="jarviswidget-editbox">
		<!-- This area used as dropdown edit box -->

	</div>
	<!-- end widget edit box -->

	<!-- widget content -->
	<div class="widget-body no-padding">
	
		<!--<form class="smart-form">-->
			<?php  print CHtml::beginForm('','POST', array('class'=>'smart-form'));?>
			<?php $this->widget('Flashes'); ?>

			<fieldset>
				foreach($columns as $column)
				{
					if($column->isPrimaryKey)
						continue;
				?>
				<section>
					<label>
						<?php echo CHtml::activeLabelEx($model,"'".$column."'"); ?>
					</label>
					<label class="input"><i class="icon-prepend fa fa-book"></i>
						<?php echo CHtml::activeTextField($model,"'".$column."'",array('size'=>255,'maxlength'=>255, 'placeholder' => '')); ?>
						<b class="tooltip tooltip-bottom-left">
							(Tooltip)
						</b> 
					</label>
				</section>
				<?php
				}
				?>
                <section>
                    <label>
                        <?php echo CHtml::activeLabelEx($model,'is_deleted'); ?>
                    </label>
                    <label class="input">
                        <?php echo CHtml::activeDropDownList($model,'is_deleted', Utilities::get_ActiveSelect(), array('class'=>'form-control')); ?>
                        <b class="tooltip tooltip-top-left">
                            (Tooltip)
                        </b> 
                    </label>
                </section>

                <div class="widget-footer smart-form">
                    <?php echo CHtml::submitButton($model->isNewRecord ? 'Update' : 'Update',  array('class'=>'btn btn-sm btn-success')); ?>
                </div>
			</fieldset>

			<?php print CHtml::endForm(); ?>
		<!--</form>-->
	</div>
	<!-- end widget content -->
</div>
<!-- end widget div -->