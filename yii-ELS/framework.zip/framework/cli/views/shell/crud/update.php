<?php
/**
 * This is the template for generating the update view for crud.
 * The following variables are available in this template:
 * - $ID: the primary key name
 * - $modelClass: the model class name
 * - $columns: a list of column schema objects
 */
?>
<!-- NEW COL START -->
<article class="col-sm-12 col-md-12 col-lg-6"><br/>

        <!-- Widget ID (each widget will need unique ID)-->
        <div class="jarviswidget jarviswidget-color-blueDark" id="wid-id-4" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false">
            <header>
				<span class="widget-icon"> <i class="fa fa-edit"></i> </span>
				<h2>Update - <?php echo $modelClass; ?></h2>
            </header>
            
            <div class="modal-content">
                <div class="smart-form" style="text-align: center;padding-bottom: 10px;">
             </div>&nbsp;
                <?php echo $this->renderPartial('_formUpdate', array('model'=>$model)); ?>
            </div>
        </div>
		
</article>