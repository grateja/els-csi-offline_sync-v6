<?php
/**
 * This is the template for generating the admin view for crud.
 * The following variables are available in this template:
 * - $ID: the primary key name
 * - $modelClass: the model class name
 * - $columns: a list of column schema objects
 */
?>
<?php 
	Yii::app()->clientScript->registerScript("javascript","
       
    $('select').select2({ width: 'resolve' });
    $('.select2-hidden-accessible').attr('hidden', true);
    $( 'input' ).addClass('form-control' );

    function reinstallDatePicker(id, data) {
            //use the same parameters that you had set in your widget else the datepicker will be refreshed by default
        $('.datePicker').datepicker(jQuery.extend({showMonthAfterYear:false},jQuery.datepicker.regional['ja'],{'dateFormat':'yy-mm-dd'}));
        
        $( 'input' ).addClass('form-control' );
        $('select').select2({ width: 'resolve' });
        $('.select2-hidden-accessible').attr('hidden', true);
    }
    ",2);
?>

<br/>
<!-- NEW COL START -->
<article class="col-sm-12 col-md-12 col-lg-12">

        <!-- Widget ID (each widget will need unique ID)-->
        <div class="jarviswidget jarviswidget-color-blueDark" id="wid-id-4" data-widget-colorbutton="false" data-widget-editbutton="false" data-widget-custombutton="false">

            <header>
                    <span class="widget-icon"> <i class="fa fa-edit"></i> </span>
                    <h2>Manage - <?php echo $modelClass; ?></h2>
            </header>
            
            <div class="modal-content">
                <div class="smart-form" style="text-align: center;padding-bottom: 10px;">
                 
                    <?php $static = array('' => Yii::t('','All'));?>
                    <?php $this->widget('zii.widgets.grid.CGridView', array(
                            'id'=>'brands-grid',
                            'dataProvider'=>$model->search(),
                            'afterAjaxUpdate' => 'reinstallDatePicker',
                            'filter'=>$model,
                            'columns'=>array(
								<?php
								$count=0;
								foreach($columns as $column)
								{
									array(
                                        'name' => ''.$column->name.'',
                                        'value' => '$data->'.$column->name.'',
                                        'filter' => false,
                                        'htmlOptions' => array(
                                             'style' => 'width: 100px;'
                                        ),
                                    ),
								}
								if($count>=7)
									echo "\t\t*/\n";
								?>
                                
                                    array(
                                        'name' => 'is_deleted',
                                        'value' => '$data->isDeleted',
                                        'filter' => $static + Utilities::get_ActiveSelect(),
                                        'htmlOptions' => array(
                                             'style' => 'width: 100px;'
                                        ),
                                    ),
                            
                                    array(
                                        'class'                => 'CButtonColumn',
                                        'header'               => 'Action',
                                        'template'             => '{view}{update}{delete}', // buttons here...
                                        'viewButtonLabel'      => '<span rel = "tooltip" style="color:#333;" class="minia-icon-search"></span>', // custom icon
                                        'viewButtonOptions'    => [ 'title' => 'View', ], // change hint/tooltip text
                                        'viewButtonImageUrl'   => false, // disable default image
                                        'updateButtonLabel'    => '<span rel = "tooltip" style="color:#333;" class="icomoon-icon-pencil"></span>', // custom icon
                                        'updateButtonOptions'  => [ 'title' => 'Update', ], // change hint/tooltip text
                                        'updateButtonImageUrl' => false, // disable default image
                                        'deleteButtonLabel'    => '<span rel = "tooltip" style="color:red;" class="icomoon-icon-remove"></span>',
                                        'deleteButtonOptions'  => [ 'title' => 'Delete', ],
                                        'deleteButtonImageUrl' => false,
                                        'deleteConfirmation'   => 'Are you sure you want to delete?', // confirmation message for delete 
                                        'htmlOptions' => array(
                                          'style' => 'width: 100px;'
                                        ),
                                    ),
                            ),
                    )); ?>
                </div>
            </div>
        </div>
</article>