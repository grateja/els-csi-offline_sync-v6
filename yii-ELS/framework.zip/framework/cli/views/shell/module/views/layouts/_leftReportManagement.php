<nav>
    <ul>
        <li class="<?php print (CustomerSalesOrderDetails::getClassActive()) . ' ' . CustomerSalesOrderDetails::getClassOpen(); ?>">
            <a href="#"><i class="fa fa-lg fa-fw fa-calendar"></i> <span class="menu-item-parent">Report Management</span></a>
            <ul>
                <li class="<?php print CustomerSalesOrderDetails::getClassSalesOrderReportActive()?>">
                        <?php print CHtml::link('Sales Order Reports', $this->createUrl('customerSalesOrderDetails/salesOrderReport')); ?>
                </li>
                <li class="<?php print CustomerSalesOrderDeliveryDetails::getClassDeliveryReportActive()?>">
                        <?php print CHtml::link('Delivery Reports', $this->createUrl('customerSalesOrderDeliveryDetails/deliveryReport')); ?>
                </li>
            </ul>
        </li>
    </ul>      
</nav>