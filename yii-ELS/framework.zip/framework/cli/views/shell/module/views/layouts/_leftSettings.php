<nav>
    <ul>
        <li class="">
                <a href="#"><i class="fa fa-lg fa-fw fa-gear"></i> <span class="menu-item-parent">Settings</span></a>
                <ul>

                    <li class="<?php print (Users::getClassActive()) . ' ' . Users::getClassOpen() .' '. Users::getClassChangePasswordActive();?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-user"></i> <span class="menu-item-parent">User</span></a>
                            <ul>
                                <?php $model = Users::model_getAccountType_byUserID(Settings::get_UserID());?>
                                <?php if($model == Utilities::YES):?>
                                        <li class="<?php print Users::getClassNewActive()?>">
                                               <?php print CHtml::link('New', $this->createUrl('users/create')); ?>
                                       </li>

                                       <li class="<?php print Users::getClassManageActive()?>">
                                               <?php print CHtml::link('Manage', $this->createUrl('users/admin')); ?>
                                       </li>
                                    <?php endif;?>
                                     <li class="<?php print Users::getClassChangePasswordActive()?>">
                                            <?php print CHtml::link('Change Password', $this->createUrl('users/changePassword', array('id'=>Settings::get_UserID()))); ?>
                                    </li>
                            </ul>
                    </li> 
                </ul>
        </li>
    </ul>
</nav>