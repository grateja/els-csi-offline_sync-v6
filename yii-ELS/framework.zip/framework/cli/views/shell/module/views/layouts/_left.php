<!-- Left panel : Navigation area -->
        <!-- Note: This width of the aside area can be adjusted through LESS variables -->
        <aside id="left-panel">

                <!-- User info -->
                <div class="login-info">
                        <span> <!-- User image size is adjusted inside CSS, it should stay as it --> 

                                <a href="javascript:void(0);" id="show-shortcut" data-action="toggleShortcut">
                                        <img src="<?php print Settings::get_baseUrl(); ?>/smartadmin/img/avatars/sunny.png" alt="me" class="online" /> 
                                        <span>
                                                <?php print Settings::get_Username(); ?> 
                                        </span>
                                        <i class="fa fa-angle-down"></i>
                                </a> 

                        </span>
                </div>
                
                <?php 
                    $model = Utilities::model_getByID(Users::model(), Settings::get_UserID());
                    if($model->account_type_id == '1'):
                ?>

                        <?php $this->renderPartial('/layouts/_leftHumanManagement');?>
                        <?php $this->renderPartial('/layouts/_leftInventoryList');?>
                        <?php $this->renderPartial('/layouts/_leftInventoryManagement');?>
                        <?php $this->renderPartial('/layouts/_leftMasterList');?>
                        <?php $this->renderPartial('/layouts/_leftProcessManagement');?>
                        <?php $this->renderPartial('/layouts/_leftSalesManagement');?>
                        <?php //$this->renderPartial('/layouts/_leftBillingManagement');?>
                        <?php $this->renderPartial('/layouts/_leftRecordManagement');?>
                        <?php $this->renderPartial('/layouts/_leftReportManagement');?>
                        <?php $this->renderPartial('/layouts/_leftSettings');?>

                <?php else:?>
                    <?php throw new CHttpException(404,'You are not authorized to access this Module.');?>
                <?php endif;?>
                
                <span class="minifyme" data-action="minifyMenu"> 
                        <i class="fa fa-arrow-circle-left hit"></i> 
                </span>

        </aside>
        <!-- END NAVIGATION -->