<nav>
    <ul>
        <li class="<?php print (CustomerSalesOrderHeaders::getClassActive()) . ' ' . CustomerSalesOrderHeaders::getClassOpen(); ?>">
            <a href="#"><i class="fa fa-lg fa-fw fa-dollar"></i> <span class="menu-item-parent">Sales Management</span></a>
            <ul>
                <li class="<?php print CustomerSalesOrderHeaders::getClassManageActive() ?>">
                    <?php print CHtml::link('Sales Order', $this->createUrl('customerSalesOrderHeaders/admin')); ?>
                </li>
                <li class="<?php print CustomerSoHeaderForApproval::getClassSoApprovalActive() ?>">
                    <?php print CHtml::link('SO Approval', $this->createUrl('customerSoHeaderForApproval/adminSOApproval')); ?>
                </li>
                <li class="<?php print CustomerSalesOrderHeaders::getClassManageDeliveryActive() ?>">
                    <?php print CHtml::link('SO Delivery', $this->createUrl('customerSalesOrderHeaders/adminDelivery')); ?>
                </li>
                <li class="<?php print CustomerSalesOrderHeaders::getClassManageConfirmationActive() ?>">
                    <?php print CHtml::link('Sales Confirmation', $this->createUrl('customerSalesOrderHeaders/adminConfirmation')); ?>
                </li>
                <li class="<?php print CustomerSoDeliveryConfirmationHeaders::getClassManageActive() ?>">
                    <?php print CHtml::link('Delivery Confirmation', $this->createUrl('customerSoDeliveryConfirmationHeaders/admin')); ?>
                </li>
                <li class=" <?php print CustomerTransactions::getClassGenerateSoaActive()?>">
                    <?php print CHtml::link('Generate SOA', $this->createUrl('customerTransactions/transactionReport')); ?>
                </li>
                <li class=" <?php print CustomerPaymentHeaders::getClassNewActive()?>">
                    <?php print CHtml::link('Payment', $this->createUrl('customerPaymentHeaders/create')); ?>
                </li>
                <li class=" <?php print CustomerTransactions::getClassManageActive()?>">
                    <?php print CHtml::link('Customer Transactions', $this->createUrl('customerTransactions/admin')); ?>
                </li>
<!--                <li class="<?php //print CustomerSalesOrderDeliveryHeaders::getClassManageActive() ?>">
                    <?php //print CHtml::link('SO Delivery', $this->createUrl('customerSalesOrderDeliveryHeaders/admin')); ?>
                </li>-->
            </ul>
        </li>
    </ul>           
</nav>