<nav>
        <ul>
            <li class="">
                    <a href="#"><i class="fa fa-lg fa-fw fa-cube"></i> <span class="menu-item-parent">Inventory Lists</span></a>
                    <ul>
                        <?php $classifications = new Classifications(); ?>
                        <?php 
                                $classifications = Classifications::model_getAllData_byDeleted(Utilities::NO);

                        ?>
                        <?php foreach($classifications as $model): ?>
                                <?php $htmlClass = ($model->html_class != '') ? $model->html_class : 'fa-fire-extinguisher'; ?>
                             
                                          
                                <li class="<?php print Inventories::getClassManageActive_byClassID($model->id)?>">
                                        <?php print CHtml::link("$model->name", $this->createUrl('inventories/admin', array('classID'=> $model->id))); ?>
                                </li>     
                        <?php endforeach; ?>
                        <!--
                        <li class="<?php print Classifications::getClassActive_byID(Classifications::OFFICE_SUPPLIES) . ' ' . Classifications::getClassOpen_byID(Classifications::OFFICE_SUPPLIES); ?>">
                                <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">Office Supplies</span></a>
                                <ul>
                                    <li class="<?php print Classifications::getClassNewActive_byID(Classifications::OFFICE_SUPPLIES)?>">
                                                <?php print CHtml::link('New', $this->createUrl('inventories/create', array('classID'=> Classifications::OFFICE_SUPPLIES))); ?>
                                        </li>

                                        <li class="<?php print Classifications::getClassManageActive_byID(Classifications::OFFICE_SUPPLIES)?>">
                                                <?php print CHtml::link('Manage', $this->createUrl('inventories/admin', array('classID'=> Classifications::OFFICE_SUPPLIES))); ?>
                                        </li>
                                </ul>
                        </li>                                                
                        <li class="<?php print Classifications::getClassActive_byID(Classifications::FIRE_TOOS_AND_SUPPLIES) . ' ' . Classifications::getClassOpen_byID(Classifications::FIRE_TOOS_AND_SUPPLIES); ?>">
                                <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">Tools and Supplies</span></a>
                                <ul>
                                    <li class="<?php print Classifications::getClassNewActive_byID(Classifications::FIRE_TOOS_AND_SUPPLIES)?>">
                                                <?php print CHtml::link('New', $this->createUrl('inventories/create', array('classID'=> Classifications::FIRE_TOOS_AND_SUPPLIES))); ?>
                                        </li>

                                        <li class="<?php print Classifications::getClassManageActive_byID(Classifications::OFFICE_SUPPLIES)?>">
                                                <?php print CHtml::link('Manage', $this->createUrl('inventories/admin', array('classID'=> Classifications::FIRE_TOOS_AND_SUPPLIES))); ?>
                                        </li>
                                </ul>
                        </li>                                                
                        <li class="<?php print Classifications::getClassActive_byID(Classifications::SPORTS_SUPPLIES) . ' ' . Classifications::getClassOpen_byID(Classifications::SPORTS_SUPPLIES); ?>">
                                <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">Sports Supplies</span></a>
                                <ul>
                                    <li class="<?php print Classifications::getClassNewActive_byID(Classifications::SPORTS_SUPPLIES)?>">
                                                <?php print CHtml::link('New', $this->createUrl('inventories/create', array('classID'=> Classifications::SPORTS_SUPPLIES))); ?>
                                        </li>

                                        <li class="<?php print Classifications::getClassManageActive_byID(Classifications::SPORTS_SUPPLIES)?>">
                                                <?php print CHtml::link('Manage', $this->createUrl('inventories/admin', array('classID'=> Classifications::SPORTS_SUPPLIES))); ?>
                                        </li>
                                </ul>
                        </li>                                                
                        <li class="<?php print Classifications::getClassActive_byID(Classifications::CMG) . ' ' . Classifications::getClassOpen_byID(Classifications::CMG); ?>">
                                <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">CMG</span></a>
                                <ul>
                                    <li class="<?php print Classifications::getClassNewActive_byID(Classifications::CMG)?>">
                                                <?php print CHtml::link('New', $this->createUrl('inventories/create', array('classID'=> Classifications::CMG))); ?>
                                        </li>

                                        <li class="<?php print Classifications::getClassManageActive_byID(Classifications::CMG)?>">
                                                <?php print CHtml::link('Manage', $this->createUrl('inventories/admin', array('classID'=> Classifications::CMG))); ?>
                                        </li>
                                </ul>
                        </li>  
                        -->

                    </ul>
            </li>
        </ul>
</nav>