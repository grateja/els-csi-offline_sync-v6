
<nav>

        <ul>
            <li class="<?php print (LocationInventories::getClassActive()) . ' ' . LocationInventories::getClassOpen(); ?>">
                <a href="#"><i class="fa fa-lg fa-fw fa-folder-open"></i> <span class="menu-item-parent">Inventory Management</span></a>
                <ul>
                    <li class="<?php print LocationInventories::getClassManageActive()?>">
                            <?php print CHtml::link('Inventory Locations', $this->createUrl('locationInventories/admin')); ?>
                    </li>
                    <li class="<?php print InventoryAdjustments::getClassManageActive()?>">
                            <?php print CHtml::link('Inventory Adjustment', $this->createUrl('inventoryAdjustments/admin')); ?>
                    </li>
                </ul>
            </li>
        </ul>      
</nav>