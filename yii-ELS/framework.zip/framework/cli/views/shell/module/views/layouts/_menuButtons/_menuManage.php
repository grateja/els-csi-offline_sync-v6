<?php echo CHtml::button('Manage', array(   
                                        'submit' => array($controller .'/admin'),
                                        'class'=>'btn btn-sm btn-primary'
                                        )); ?>
