<nav>
        <ul>
            <li class="<?php //print (RoomInventories::getClassActive()) . ' ' . RoomInventories::getClassOpen(); ?>">
                    <a href="#"><i class="fa fa-lg fa-fw fa-check-square-o"></i> <span class="menu-item-parent">Masterlist</span></a>
                    <ul>
                        <li class="<?php print Inventories::getClassPrintActive() ?>">
                                    <?php print CHtml::link('Inventory Management', $this->createUrl('inventories/print')); ?>
                            </li>

                            <!--<li class="<?php print RoomInventories::getClassPrintActive()?>">
                                    <?php print CHtml::link('Room Assignment', $this->createUrl('roomInventories/print')); ?>
                            </li>-->
                    </ul>
            </li>
        </ul>           
</nav>