<nav>
    <ul>
        <li class="<?php //print (RoomInventories::getClassActive()) . ' ' . RoomInventories::getClassOpen(); ?>">
                <a href="#"><i class="fa fa-lg fa-fw fa-delicious "></i> <span class="menu-item-parent">Process Management</span></a>
                <ul>
                    <li class="<?php print (PropertiesRequisitionDetails::getClassActive()) . ' ' . PropertiesRequisitionDetails::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-paper-plane"></i> <span class="menu-item-parent">Property Requisition</span></a>
                            <ul>
<!--                                     <li class="<?php //print PropertiesRequisitionDetails::getClassNewActive()?>">
                                            <?php //print CHtml::link('New', $this->createUrl('propertiesRequisitionDetails/index')); ?>
                                    </li>-->

                                    <li class="<?php print PropertiesRequisitionHeaders::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage', $this->createUrl('propertiesRequisitionHeaders/admin')); ?>
                                    </li>
                            </ul>
                    </li>

                    <li class="<?php  print (SuppliesRequisitionDetails::getClassActive()) . ' ' . SuppliesRequisitionDetails::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-fax"></i> <span class="menu-item-parent">Supplies Requisition<!--Stock Item Request--></span></a>
                            <ul>
<!--                                    <li class="<?php  //print SuppliesRequisitionDetails::getClassNewActive()?>">
                                            <?php //print CHtml::link('New', $this->createUrl('suppliesRequisitionDetails/index')); ?>
                                    </li>-->

                                    <li class="<?php  print SuppliesRequisitionHeaders::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage', $this->createUrl('suppliesRequisitionHeaders/admin')); ?>
                                            <?php //print CHtml::link('Manage', $this->createUrl('suppliesRequisitionDetails/admin')); ?>
                                    </li>
                                    <li class="<?php  print SuppliesRequisitionHeaders::getClassForApprovalActive()?>">
                                            <?php print CHtml::link('For Approval', $this->createUrl('suppliesRequisitionHeaders/forApproval')); ?>
                                            <?php //print CHtml::link('Manage', $this->createUrl('suppliesRequisitionDetails/admin')); ?>
                                    </li>

                            </ul>
                    </li>

                    <li class="<?php print (PurchaseOrderHeaders::getClassActive()) . ' ' . PurchaseOrderHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-ra"></i> <span class="menu-item-parent">Properties P.O</span></a>
                            <ul>
                                <li class="<?php  print PurchaseOrderHeaders::getClassNewActive();?>">
                                            <?php print CHtml::link('New',$this->createUrl('purchaseOrderHeaders/adminRequisition')); ?>
                                    </li>

                                    <li class="<?php print PurchaseOrderHeaders::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage',$this->createUrl('purchaseOrderHeaders/admin')); ?>
                                    </li>

                                    <li class="<?php print PurchaseOrderHeaders::getClassOverrideActive()?>">
                                            <?php print CHtml::link('Override',$this->createUrl('purchaseOrderHeaders/override')); ?>
                                    </li>
                            </ul>
                    </li>

                    <li class="<?php print (SuppliesRequisitionForpoHeaders::getClassActive()) . ' ' . SuppliesRequisitionForpoHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-space-shuttle "></i> <span class="menu-item-parent">Supplies P.O</span></a>
                            <ul>
                                <li class="<?php  print SuppliesRequisitionForpoHeaders::getClassAdminRequisitionActive();?>">
                                            <?php print CHtml::link('New',$this->createUrl('suppliesRequisitionForpoHeaders/adminRequisition')); ?>
                                    </li>

                                    <li class="<?php print PurchaseOrderSuppliesHeaders::getClassManageActive();?>">
                                            <?php print CHtml::link('Manage',$this->createUrl('purchaseOrderSuppliesHeaders/admin')); ?>
                                    </li>

                                    <li class="<?php print PurchaseOrderSuppliesHeaders::getClassOverrideActive()?>">
                                            <?php print CHtml::link('Override',$this->createUrl('purchaseOrderSuppliesHeaders/override')); ?>
                                    </li>

                            </ul>
                    </li>
                    <li class="<?php  //print (PurchaseReceivingHeaders::getClassActive()) . ' ' . PurchaseReceivingHeaders::getClassOpen(); ?>">
                        <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">Delivery Receipts</span></a>     
                        <ul>
                        <li class="<?php  print (PurchaseReceivingHeaders::getClassActive()) . ' ' . PurchaseReceivingHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-taxi"></i> <span class="menu-item-parent">Property</span></a>
                            <ul>
                                <li class="<?php  print PurchaseReceivingHeaders::getClassNewActive()?>">
                                    <?php print CHtml::link('New',$this->createUrl('purchaseReceivingHeaders/deliveryReceipts')); ?>
                                </li>

                                <li class="<?php  print PurchaseReceivingHeaders::getClassManageActive()?>">
                                    <?php print CHtml::link('Manage',$this->createUrl('purchaseReceivingHeaders/admin')); ?>
                                </li>
                            </ul>
                        </li>
                        <li class="<?php  print (SuppliesReceivingHeaders::getClassActive()) . ' ' . SuppliesReceivingHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-drupal"></i> <span class="menu-item-parent">Supplies</span></a>
                            <ul>
                                <li class="<?php  print SuppliesReceivingHeaders::getClassNewActive()?>">
                                    <?php print CHtml::link('New',$this->createUrl('suppliesReceivingHeaders/deliveryReceipts')); ?>
                                </li>

                                <li class="<?php  print SuppliesReceivingHeaders::getClassManageActive()?>">
                                    <?php print CHtml::link('Manage',$this->createUrl('suppliesReceivingHeaders/admin')); ?>
                                </li>
                            </ul>
                        </li>     
                        </ul>
                    </li>

                    <li class="<?php  print (InventoryDetails::getClassActive()) . ' ' . InventoryDetails::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-slack"></i> <span class="menu-item-parent">Asset Tagging</span></a>
                            <ul>
                                <li class="<?php print InventoryDetails::getClassManageInventoriesActive()?>">
                                            <?php print CHtml::link('New', $this->createUrl('inventoryDetails/adminInventories')); ?>
                                    </li>

                                    <li class="<?php  print InventoryDetails::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage', $this->createUrl('inventoryDetails/admin')); ?>
                                    </li>
                            </ul>
                    </li>

                    <li class="<?php  print (PropertiesIssuanceHeaders::getClassActive()) . ' ' . PropertiesIssuanceHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-spoon"></i> <span class="menu-item-parent">P.R Release</span></a>
                            <ul>
                                <li class="<?php  print PropertiesIssuanceHeaders::getClassAdminForIssuanceActive()?>">
                                            <?php print CHtml::link('New', $this->createUrl('propertiesRequisitionHeaders/adminForIssuance')); ?>
                                    </li>

                                    <li class="<?php  print PropertiesIssuanceHeaders::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage', $this->createUrl('propertiesIssuanceHeaders/admin')); ?>
                                    </li>
                            </ul>
                    </li>

                    <li class="<?php  print (SuppliesIssuanceHeaders::getClassActive()) . ' ' . SuppliesIssuanceHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-stumbleupon"></i> <span class="menu-item-parent">S.R Release</span></a>
                            <ul>
                                     <li class="<?php  print SuppliesIssuanceHeaders::getClassAdminForIssuanceActive()?>">
                                            <?php print CHtml::link('New',$this->createUrl('suppliesRequisitionHeaders/adminForIssuance')); ?>
                                    </li>

                                    <li class="<?php  print SuppliesIssuanceHeaders::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage',$this->createUrl('suppliesIssuanceHeaders/admin')); ?>
                                    </li>
                            </ul>
                    </li>

                    <li class="<?php  print (PropertiesTransferHeaders::getClassActive()) . ' ' . PropertiesTransferHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-wechat"></i> <span class="menu-item-parent">Stocks-Asset Transfer</span></a>
                            <ul>
                                     <li class="<?php  print PropertiesTransferHeaders::getClassNewActive()?>">
                                            <?php print CHtml::link('New', $this->createUrl('propertiesTransferHeaders/selectLocation')); ?>
                                    </li>

                                    <li class="<?php  print PropertiesTransferHeaders::getClassManageActive()?>">
                                            <?php print CHtml::link('Manage',$this->createUrl('propertiesTransferHeaders/admin')); ?>
                                    </li>
                            </ul>
                    </li>

                    <li class="<?php  print (PropertiesDisposableHeaders::getClassActive()) . ' ' . PropertiesDisposableHeaders::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">Stocks-Asset Disposal</span></a>
                            <ul>
                                <li class="<?php  print (PropertiesDisposableDetails::getClassActive()) . ' ' . PropertiesDisposableDetails::getClassOpen(); ?>">
                                    <a href="#"><i class="fa fa-lg fa-fw fa-empire"></i> <span class="menu-item-parent">New</span></a>
                                        <ul>
                                            <li class="<?php  print PropertiesDisposableDetails::getClassManualDisposalActive(); ?>">
                                                    <?php print CHtml::link('Manual',$this->createUrl('propertiesDisposableDetails/manualDisposal')); ?>
                                            </li>

                                            <li class="<?php  print PropertiesDisposableDetails::getClassAdminDisposalActive(); ?>">
                                                    <?php print CHtml::link('Zero(0) Booked Value',$this->createUrl('propertiesDisposableDetails/adminDisposal')); ?>
                                            </li>
                                        </ul>
                                </li>
                                    <li class="<?php  print PropertiesDisposableHeaders::getClassManageActive(); ?>">
                                            <?php print CHtml::link('Manage',$this->createUrl('propertiesDisposableHeaders/admin')); ?>
                                    </li>

                            </ul>
                    </li>

                </ul>
        </li>
    </ul>  
</nav>