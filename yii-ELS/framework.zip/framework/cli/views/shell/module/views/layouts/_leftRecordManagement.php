<nav>
    <ul>
        <li class="<?php //print (RoomInventories::getClassActive()) . ' ' . RoomInventories::getClassOpen(); ?>">
                <a href="#"><i class="fa fa-lg fa-fw fa-pencil"></i> <span class="menu-item-parent">Record Management</span></a>
                <ul>
                    <li class="<?php print (Barangays::getClassActive()) . ' ' . Barangays::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-institution"></i> <span class="menu-item-parent">Barangays</span></a>
                            <ul>
                                <li class="<?php print Barangays::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('barangays/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Brands::getClassActive()) . ' ' . Brands::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-history"></i> <span class="menu-item-parent">Brands</span></a>
                            <ul>
                                <li class="<?php print Brands::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('brands/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (ClassificationPropertyGroups::getClassActive()) . ' ' . ClassificationPropertyGroups::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-crosshairs"></i> <span class="menu-item-parent">Classif. Sub Groups</span></a>
                            <ul>
                                <li class="<?php print ClassificationPropertyGroups::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('classificationPropertyGroups/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Departments::getClassActive()) . ' ' . Departments::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-dot-circle-o"></i> <span class="menu-item-parent">Departments</span></a>
                            <ul>
                                <li class="<?php print Departments::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('departments/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Floors::getClassActive()) . ' ' . Floors::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-sliders"></i> <span class="menu-item-parent">Floors</span></a>
                            <ul>
                                <li class="<?php print Floors::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('floors/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (ItemTypes::getClassActive()) . ' ' . ItemTypes::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-file-o"></i> <span class="menu-item-parent">Item Types</span></a>
                            <ul>
                                <li class="<?php print ItemTypes::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('itemTypes/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Locations::getClassActive()) . ' ' . Locations::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-minus-square"></i> <span class="menu-item-parent">Locations</span></a>
                            <ul>
                                <li class="<?php print Locations::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('locations/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Municipalities::getClassActive()) . ' ' . Municipalities::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-bars"></i> <span class="menu-item-parent">Municipalities</span></a>
                            <ul>
                                <li class="<?php print Municipalities::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('municipalities/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (PropertyGroups::getClassActive()) . ' ' . PropertyGroups::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-tree"></i> <span class="menu-item-parent">Property Groups</span></a>
                            <ul>
                                <li class="<?php print PropertyGroups::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('propertyGroups/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Provinces::getClassActive()) . ' ' . Provinces::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-bomb"></i> <span class="menu-item-parent">Provinces</span></a>
                            <ul>
                                <li class="<?php print Provinces::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('provinces/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Regions::getClassActive()) . ' ' . Regions::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-building-o"></i> <span class="menu-item-parent">Regions</span></a>
                            <ul>
                                <li class="<?php print Regions::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('regions/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (RoomTypes::getClassActive()) . ' ' . RoomTypes::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-sort-numeric-asc"></i> <span class="menu-item-parent">Room Types</span></a>
                            <ul>
                                <li class="<?php print RoomTypes::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('roomTypes/admin')); ?>
                                </li>
                            </ul>
                    </li>  
                    <li class="<?php print (Rooms::getClassActive()) . ' ' . Rooms::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-anchor"></i> <span class="menu-item-parent">Rooms</span></a>
                            <ul>
                                <li class="<?php print Rooms::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('rooms/admin')); ?>
                                </li>
                            </ul>
                    </li>  
                    <li class="<?php print (Segments::getClassActive()) . ' ' . Segments::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-book"></i> <span class="menu-item-parent">Segments</span></a>
                            <ul>
                                <li class="<?php print Segments::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('segments/admin')); ?>
                                </li>
                            </ul>
                    </li>   
                    <li class="<?php print (Suppliers::getClassActive()) . ' ' . Suppliers::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-bar-chart-o"></i> <span class="menu-item-parent">Suppliers</span></a>
                            <ul>
                                <li class="<?php print Suppliers::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('suppliers/admin')); ?>
                                </li>
                            </ul>
                    </li>
                    <li class="<?php print (Units::getClassActive()) . ' ' . Units::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-bell-o"></i> <span class="menu-item-parent">Units</span></a>
                            <ul>
                                <li class="<?php print Units::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('units/admin')); ?>
                                </li>
                            </ul>
                    </li>   
                    <li class="<?php print (Classifications::getClassActive()) . ' ' . Classifications::getClassOpen(); ?>">
                            <a href="#"><i class="fa fa-lg fa-fw fa-paragraph"></i> <span class="menu-item-parent">Warehouse Classif.</span></a>
                            <ul>
                                <li class="<?php print Classifications::getClassManageActive()?>">
                                        <?php print CHtml::link('Manage', $this->createUrl('classifications/admin')); ?>
                                </li>
                            </ul>
                    </li>

                </ul>
        </li>
    </ul>        
</nav>