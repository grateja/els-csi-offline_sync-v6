<nav>
    <ul>
        <li class="<?php print (CustomerPaymentHeaders::getClassActive()) . ' ' . CustomerPaymentHeaders::getClassOpen(); ?>">
            <a href="#"><i class="fa fa-lg fa-fw fa-paper-plane"></i> <span class="menu-item-parent">Billing Management</span></a>
            <ul>
                <li class=" <?php print CustomerPaymentHeaders::getClassNewActive()?>">
                        <?php print CHtml::link('Payment', $this->createUrl('customerPaymentHeaders/create')); ?>
                </li>

                <li class=" <?php print CustomerTransactions::getClassGenerateSoaActive()?>">
                        <?php print CHtml::link('Generate SOA', $this->createUrl('customerTransactions/transactionReport')); ?>
                </li>
            </ul>
        </li>                                   
    </ul>
</nav>    