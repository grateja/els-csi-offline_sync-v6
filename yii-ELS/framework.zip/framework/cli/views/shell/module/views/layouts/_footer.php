		<!-- PAGE FOOTER -->
<!--		<div class="page-footer">
			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<span class="txt-color-white">Tranzend Solutions and Trading Corp.</span>
				</div>

				<div class="col-xs-6 col-sm-6 text-right hidden-xs">
					<div class="txt-color-white inline-block">
						<i class="txt-color-blueLight hidden-mobile">Last account activity <i class="fa fa-clock-o"></i> <strong>52 mins ago &nbsp;</strong> </i>
						<div class="btn-group dropup">
							<button class="btn btn-xs dropdown-toggle bg-color-blue txt-color-white" data-toggle="dropdown">
								<i class="fa fa-link"></i> <span class="caret"></span>
							</button>
							<ul class="dropdown-menu pull-right text-left">
								<li>
									<div class="padding-5">
										<p class="txt-color-darken font-sm no-margin">Download Progress</p>
										<div class="progress progress-micro no-margin">
											<div class="progress-bar progress-bar-success" style="width: 50%;"></div>
										</div>
									</div>
								</li>
								<li class="divider"></li>
								<li>
									<div class="padding-5">
										<p class="txt-color-darken font-sm no-margin">Server Load</p>
										<div class="progress progress-micro no-margin">
											<div class="progress-bar progress-bar-success" style="width: 20%;"></div>
										</div>
									</div>
								</li>
								<li class="divider"></li>
								<li>
									<div class="padding-5">
										<p class="txt-color-darken font-sm no-margin">Memory Load <span class="text-danger">*critical*</span></p>
										<div class="progress progress-micro no-margin">
											<div class="progress-bar progress-bar-danger" style="width: 70%;"></div>
										</div>
									</div>
								</li>
								<li class="divider"></li>
								<li>
									<div class="padding-5">
										<button class="btn btn-block btn-default">refresh</button>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		 END PAGE FOOTER 
                
                 SHORTCUT AREA : With large tiles (activated via clicking user name tag)
		Note: These tiles are completely responsive,
		you can add as many as you like
		
		<div id="shortcut">
			<ul>
				<li>
					<a href="#inbox.html" class="jarvismetro-tile big-cubes bg-color-blue"> <span class="iconbox"> <i class="fa fa-envelope fa-4x"></i> <span>Mail <span class="label pull-right bg-color-darken">14</span></span> </span> </a>
				</li>
				<li>
					<a href="#calendar.html" class="jarvismetro-tile big-cubes bg-color-orangeDark"> <span class="iconbox"> <i class="fa fa-calendar fa-4x"></i> <span>Calendar</span> </span> </a>
				</li>
				<li>
					<a href="#gmap-xml.html" class="jarvismetro-tile big-cubes bg-color-purple"> <span class="iconbox"> <i class="fa fa-map-marker fa-4x"></i> <span>Maps</span> </span> </a>
				</li>
				<li>
					<a href="#invoice.html" class="jarvismetro-tile big-cubes bg-color-blueDark"> <span class="iconbox"> <i class="fa fa-book fa-4x"></i> <span>Invoice <span class="label pull-right bg-color-darken">99</span></span> </span> </a>
				</li>
				<li>
					<a href="#gallery.html" class="jarvismetro-tile big-cubes bg-color-greenLight"> <span class="iconbox"> <i class="fa fa-picture-o fa-4x"></i> <span>Gallery </span> </span> </a>
				</li>
				<li>
					<a href="javascript:void(0);" class="jarvismetro-tile big-cubes selected bg-color-pinkDark"> <span class="iconbox"> <i class="fa fa-user fa-4x"></i> <span>My Profile </span> </span> </a>
				</li>
			</ul>
		</div>-->
		<!-- END SHORTCUT AREA -->
                
                <!--================================================== -->

		<!-- PACE LOADER - turn this on if you want ajax loading to show (caution: uses lots of memory on iDevices)-->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/pace/pace.min.js"></script>

		<!-- Link to Google CDN's jQuery + jQueryUI; fall back to local -->
                <!--
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script>
			if (!window.jQuery) {
				document.write('<script src="js/libs/jquery-2.0.2.min.js"><\/script>');
			}
		</script>
                -->
                <style>
                    
                     /* grid border */
                    .grid-view header {
                        color: #333;
                    } 
                    .grid-view table.items th {
                      background: #4C4F53!important;
                      color: #fff;
                      text-align: center;
                      text-transform: uppercase;
                    }
                    
                    .grid-view table.items th, .grid-view table.items td {
                        border: 1px solid gray !important;
                        text-align: center;
                        font-size: 13px;
                    }
                    
                    .grid-view table.items td {
                      color: black;
                    }
                    
                    .label-success, .label-danger {
                        text-transform: uppercase;
                    }
                    
                    /* disable selected for merged cells */     
                    .grid-view td.merge {
                       background: none repeat scroll 0 0 #F8F8F8; 
                    }

                    .subtotal{
                       float: right  !important;
                       font-weight: bold !important;
                       font-size: 14px !important;
                       margin-right: 17px !important;
                    }
                    
                    ul.yiiPager a:link, ul.yiiPager a:visited {
                        border: solid 1px #4C4F53;
                        color: #4C4F53;
                    }
                    
                    .grid-view table.items th{
                        background: #4C4F53;
                    } 
                    .grid-view ul.yiiPager .selected a{
                        background: #4C4F53;
                        color: #FFFFFF;
                        font-size: 13px;
                    }
                    
                    #ribbon .breadcrumb li:last-child, #ribbon .breadcrumb>.active, .breadcrumb>li {
                        color: #f3f3f3;
                        font-size: 15px;
                    }

/*                    .jarviswidget>header {
                        color: #fff;
                        border: 1px solid #4C4F53 !important;
                        background: #4C4F53;
                    }*/
                    
                    
                </style>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<script>
			if (!window.jQuery.ui) {
				document.write('<script src="js/libs/jquery-ui-1.10.3.min.js"><\/script>');
			}
		</script>

		<!-- IMPORTANT: APP CONFIG -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/app.config.js"></script>

		<!-- JS TOUCH : include this plugin for mobile drag / drop touch events-->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/jquery-touch/jquery.ui.touch-punch.min.js"></script> 

		<!-- BOOTSTRAP JS -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/bootstrap/bootstrap.min.js"></script>

		<!-- CUSTOM NOTIFICATION -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/notification/SmartNotification.min.js"></script>

		<!-- JARVIS WIDGETS -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/smartwidgets/jarvis.widget.min.js"></script>

		<!-- EASY PIE CHARTS -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js"></script>

		<!-- SPARKLINES -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/sparkline/jquery.sparkline.min.js"></script>

		<!-- JQUERY VALIDATE -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/jquery-validate/jquery.validate.min.js"></script>

		<!-- JQUERY MASKED INPUT -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/masked-input/jquery.maskedinput.min.js"></script>

		<!-- JQUERY SELECT2 INPUT -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/select2/select2.min.js"></script>
                <!--X-Editable-->
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/x-editable/x-editable.min.js"></script>
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/x-editable/moment.min.js"></script>
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/x-editable/jquery.mockjax.min.js"></script>
                
		
		<!-- JQUERY UI + Bootstrap Slider -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/bootstrap-slider/bootstrap-slider.min.js"></script>

		<!-- browser msie issue fix -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/msie-fix/jquery.mb.browser.min.js"></script>

		<!-- FastClick: For mobile devices -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/fastclick/fastclick.min.js"></script>

		<!-- clockpicker -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/clockpicker/clockpicker.min.js"></script>
                
                <!-- JQUERY intl-tel-input-master -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/intl-tel-input-master/build/js/intlTelInput.min.js"></script>
                <script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/intl-tel-input-master/build/js/intlTelInput.js"></script>

		<!--[if IE 8]>

		<h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>

		<![endif]-->

		<!-- Demo purpose only -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/demo.min.js"></script>

		<!-- MAIN APP JS FILE -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/app.min.js"></script>

		<!-- ENHANCEMENT PLUGINS : NOT A REQUIREMENT -->
		<!-- Voice command : plugin -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/speech/voicecommand.min.js"></script>
		
		
		<!-- PAGE nestable) -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/jquery-nestable/jquery.nestable.min.js"></script>
                
		<!-- Flot Chart Plugin: Flot Engine, Flot Resizer, Flot Tooltip -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/flot/jquery.flot.cust.min.js"></script>
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/flot/jquery.flot.resize.min.js"></script>
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/flot/jquery.flot.tooltip.min.js"></script>
		
		<!-- Vector Maps Plugin: Vectormap engine, Vectormap language -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/vectormap/jquery-jvectormap-1.2.2.min.js"></script>
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/vectormap/jquery-jvectormap-world-mill-en.js"></script>
		
		<!-- Full Calendar -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/fullcalendar/jquery.fullcalendar.min.js"></script>
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/alertify/alertify.min.js"></script>
		<?php //$this->renderPartial('/layouts/_footerScript');?>
                <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>-->
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/loadingOverlay/waitMe.js"></script>
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/loadingOverlay/scripts.js"></script>
                
                <!-- datatables -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/datatables/jquery.dataTables.min.js"></script>
                
               
