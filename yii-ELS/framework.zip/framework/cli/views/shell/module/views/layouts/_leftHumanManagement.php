<nav>
        <ul>
                <li class="<?php print (Defaults::getClassActive()); ?>">
                        <?php print CHtml::link('<i class=\'fa fa-lg fa-fw fa-home\'></i><span class="menu-item-parent">Dashboard</span>', $this->createUrl('default/index'), array('title'=>'Dashboard','class'=>'menu-item-parent')); ?>
                </li>
        </ul>
        <ul>
            <li class="<?php //print (RoomInventories::getClassActive()) . ' ' . RoomInventories::getClassOpen(); ?>">
                    <a href="#"><i class="fa fa-lg fa-fw fa-male"></i> <span class="menu-item-parent">Human Management</span></a>
                       <ul>
                                <li class="<?php print Employees::getClassManageActive()?>">
                                        <?php print CHtml::link('Employees', $this->createUrl('employees/admin')); ?>
                                </li>
                       
                                <li class="<?php print Customers::getClassManageActive()?>">
                                        <?php print CHtml::link('Customers', $this->createUrl('customers/admin')); ?>
                                </li>
                        </ul>

        </ul>      
</nav>