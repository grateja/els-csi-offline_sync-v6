<?php

class DefaultController extends SiteadminController
{
	public function actionIndex()
	{
                     

                $this->render('index');
	}
        
      
}