        <?php  print CHtml::beginForm('','POST', array('class'=>'smart-form'));?>
                    <?php //$this->widget('Flashes'); ?>


                        <table class="table table-bordered table-responsive" style="width: 100%; margin-left: auto; margin-right: auto;">
                                    <thead>
                                            <th colspan="2" style="text-align: center;">Username/Password Details</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td style="text-align: left;"><?php echo CHtml::activeLabelEx($model,'username');?></td>
                                            <td style="text-align: left;"> 
                                                <?php 
                                                print $model->username;
                                                //echo CHtml::activeTextField($model,'username',array('class'=>'form-control','disabled'=>'disabled','style' => 'background-color: lightgray;')); 
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left; "> <?php echo CHtml::activeLabelEx($model,'old_password');?></td>
                                            <td style="text-align: left;"> 
                                                <?php echo CHtml::activePasswordField($model,'old_password', array('class' => 'form-control')); ?>
                                            </td>
                                        </tr>       
                                        <tr>
                                            <td style="text-align: left; "> <?php echo CHtml::activeLabelEx($model,'new_password');?></td>
                                            <td style="text-align: left; "> 
                                                <?php echo CHtml::activePasswordField($model,'new_password', array('class' => 'form-control')); ?>
                                            </td>
                                        </tr>    
                                        <tr>
                                            <td style="text-align: left; "> <?php echo CHtml::activeLabelEx($model,'repeat_password');?></td>
                                            <td style="text-align: left; "> 
                                                <?php echo CHtml::activePasswordField($model,'repeat_password', array('class' => 'form-control')); ?>
                                            </td>
                                        </tr>      
                                        <tr>
                                            <td style="text-align: center; width: 100%;" colspan="2"> 
                                                <?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Change Password',  array('class'=>'btn btn-sm btn-success ')); ?>
                                            </td>
                                        </tr>                                              
                                    </tbody>
                        </table>
                <?php print CHtml::endForm(); ?>