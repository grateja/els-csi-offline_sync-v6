$(document).ready(function () {
responsiveMenu(),
//Prevent collapse of children when one child is clicked
$('.horizontal_menu ul').click(function(e){
   e.stopPropagation(); 
});

$('ul').not(':has(li)').remove(); //general removal of empty UL's

$("thead").click(function () {
//$(this).parent().next("div").stop().slideToggle(1000);
$('#room_schedule_wrapper').stop().slideToggle(1000);
});

/*
if($('ul:has(li)',this)){
$('ul li a',this).each(function() {
$(this).append('<i class= "fa fa-plus" ></i>');
});
}
*/

});

$(window).resize(function () {
responsiveMenu();
});



function responsiveMenu(){

var $browserWidth = window.innerWidth||document.documentElement.clientWidth;

if ($browserWidth > 768){

$('.horizontal_menu li ul').stop().hide();

$('ul').first().stop().show();
$('.horizontal_menu li').unbind().bind({
mouseenter: function (e) {
$(this).find('ul').first().stop().fadeIn();
},
mouseleave: function (e) {
$(this).find('ul').first().stop().fadeOut();
}
})

}

else 
{

$('.horizontal_menu ul li').unbind().click(function(){
$('ul',this).first().stop().slideToggle();
}),
$('.menu').unbind().click(function(){
$('ul').first().stop().slideToggle();
$('.horizontal_menu li ul').stop().slideUp('fast');
})
}
}