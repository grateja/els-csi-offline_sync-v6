<!--================================================== -->	
        <script type="text/javascript">
                      function showSpinnerSmall(val)
                      {
                        $('#' + val).addClass('displayYes');
                      }
                      function hideSpinnerSmall(val)
                      {
                        $('#' + val).removeClass().addClass('displayNo');
                      }

                </script>    
		<!-- PACE LOADER - turn this on if you want ajax loading to show (caution: uses lots of memory on iDevices)-->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/pace/pace.min.js"></script>

	    <!-- Link to Google CDN's jQuery + jQueryUI; fall back to local -->
	    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script> if (!window.jQuery) { document.write('<script src="js/libs/jquery-2.0.2.min.js"><\/script>');} </script>

	    <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<script> if (!window.jQuery.ui) { document.write('<script src="js/libs/jquery-ui-1.10.3.min.js"><\/script>');} </script>

		<!-- JS TOUCH : include this plugin for mobile drag / drop touch events 		
		<script src="js/plugin/jquery-touch/jquery.ui.touch-punch.min.js"></script> -->

		<!-- BOOTSTRAP JS -->		
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/bootstrap/bootstrap.min.js"></script>

		<!-- clockpicker -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/clockpicker/clockpicker.min.js"></script>
		
		<!-- JQUERY VALIDATE -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/jquery-validate/jquery.validate.min.js"></script>
		
		<!-- JQUERY MASKED INPUT -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/masked-input/jquery.maskedinput.min.js"></script>
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/intl-tel-input-master/build/js/intlTelInput.min.js"></script>
                <script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/intl-tel-input-master/build/js/intlTelInput.js"></script>
		<!--[if IE 8]>
			
			<h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>
			
		<![endif]-->
      <!--X-Editable-->\
                <script src="<?php  print Settings::get_baseUrl(); ?>/smartadmin/js/plugin/x-editable/x-editable.min.js"></script>
                
        <!-- MAIN APP CONFIG JS FILE -->
        <script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/app.config.js"></script>

		<!-- MAIN APP JS FILE -->
		<script src="<?php print Settings::get_baseUrl(); ?>/smartadmin/js/app.min.js"></script>

		<script type="text/javascript">

                    $('#txtUsername').keypress(function(e) {
                        if(e.which == 13) {
                                 //alert('You pressed enter!');
                                 $('#txtPassword').focus();
                        }
                    });


                    $('#txtPassword').keypress(function(e) {
                        if(e.which == 13) {
                                 //alert('You pressed enter!');
                                 $('#cmdLogin').focus();
                        }
                    });
			//runAllForms();

                        /*
			$(function() {
				// Validation
				$("#login-form").validate({
					// Rules for form validation
					rules : {
						email : {
							required : true,
							email : true
						},
						password : {
							required : true,
							minlength : 3,
							maxlength : 20
						}
					},

					// Messages for form validation
					messages : {
						email : {
							required : 'Please enter your email address',
							email : 'Please enter a VALID email address'
						},
						password : {
							required : 'Please enter your password'
						}
					},

					// Do not change code below
					errorPlacement : function(error, element) {
						error.insertAfter(element.parent());
					}
				});
			});
                        */
		</script>